def main():
  print('This is the main function')
  
if __name__ == "__main__":
  main()